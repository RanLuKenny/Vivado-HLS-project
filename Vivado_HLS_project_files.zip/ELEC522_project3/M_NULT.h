#ifndef __MATRIXMUL_H__
#define __MATRIXMUL_H__

void Matrix_multiplication (short Matrix_A[4][4],
							short Matrix_B[4][4],
							short Matrix_C[4][4]);

#endif

