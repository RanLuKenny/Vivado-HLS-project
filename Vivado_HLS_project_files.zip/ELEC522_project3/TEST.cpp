#include <iostream>
#include "M_NULT.h"
using namespace std;

int main(int argc, char **argv)
{
	short in_mat_a[4][4] = {
      {1,3,5,7},
      {9,11,13,15},
      {17,19,21,23},
      {25,27,29,31}
   };
	short in_mat_b[4][4] = {
      {2,4,6,8},
      {10,12,14,16},
      {18,20,22,24},
      {26,28,30,32},
   };
    short hw_result[4][4];
    Matrix_multiplication (in_mat_a, in_mat_b, hw_result);

   for ( short p = 0 ; p != 4; p++) {
                  for ( short q = 0; q !=4; q++) {
                     cout<<hw_result[p][q]<<' ';
                  }
          cout<<endl;
      }
   return 0;
}
