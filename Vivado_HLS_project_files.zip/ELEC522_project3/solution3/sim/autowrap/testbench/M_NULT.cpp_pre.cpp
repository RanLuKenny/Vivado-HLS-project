# 1 "L:/522_project3/ELEC522_project3/M_NULT.cpp"
# 1 "<built-in>"
# 1 "<command-line>"
# 1 "L:/522_project3/ELEC522_project3/M_NULT.cpp"
# 1 "L:/522_project3/ELEC522_project3/M_NULT.h" 1



void Matrix_multiplication (short Matrix_A[4][4],
       short Matrix_B[4][4],
       short Matrix_C[4][4]);
# 2 "L:/522_project3/ELEC522_project3/M_NULT.cpp" 2
void Matrix_multiplication (short Matrix_A[4][4],
  short Matrix_B[4][4],
  short Matrix_C[4][4])
{


 Matrix_multiplication_label9:Matrix_multiplication_label11:for(short i=0; i!=4; i++)
 {
#pragma HLS PIPELINE
  Matrix_multiplication_label7:for (short j=0; j!=4; j++)
  {
#pragma HLS PIPELINE
   Matrix_C[i][j]=0;
   Matrix_multiplication_label8:Matrix_multiplication_label10:for(short k=0; k!=4; k++)

#pragma HLS PIPELINE
Matrix_C[i][j] += Matrix_A[i][k] * Matrix_B[k][j];
  }
 }
}
