#include"M_NULT.h"
void Matrix_multiplication (short Matrix_A[4][4],
		short Matrix_B[4][4],
		short Matrix_C[4][4])
{

	Matrix_multiplication_label2:for(short i=0; i!=4; i++)
	{
		Matrix_multiplication_label1:for (short j=0; j!=4; j++)
		{

			Matrix_C[i][j]=0;
			Matrix_multiplication_label0:for(short k=0; k!=4; k++)

				Matrix_C[i][j] += Matrix_A[i][k] * Matrix_B[k][j];
		}
	}
}

